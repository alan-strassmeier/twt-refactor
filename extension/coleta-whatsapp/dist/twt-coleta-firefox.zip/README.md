# TWT - Envio de coletas pelo WhatsApp

WebExtension para Chrome e Firefox. A extensão consulta uma coleta pelo backend
da TWT, permite escolher um contato salvo localmente, revisar a mensagem e abre
o WhatsApp para que o funcionário confirme o envio.

## Segurança

A extensão nunca recebe as credenciais nem o JWT da Brudam. Ela usa um token
interno próprio, limitado ao endpoint de consulta de coleta. Contatos e
configuração ficam em `storage.local` no perfil do navegador.

Configure na Vercel:

```text
COLETA_EXTENSION_TOKEN=<valor aleatório com no mínimo 32 caracteres>
COLETA_ALLOWED_ORIGINS=<opcional; origens da extensão separadas por vírgula>
BRUDAM_API_USER=<usuário da tela 669>
BRUDAM_API_PASSWORD=<senha da tela 669>
BRUDAM_API_URL=https://twt.brudam.com.br/api/v1
```

Para gerar o token no PowerShell:

```powershell
$bytes = New-Object byte[] 48
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($bytes)
$rng.Dispose()
[Convert]::ToBase64String($bytes)
```

Após cadastrar as variáveis, faça um novo deployment. Informe na extensão o
mesmo `COLETA_EXTENSION_TOKEN` e o endereço público do projeto TWT.

## Instalação local no Chrome

1. Abra `chrome://extensions`.
2. Ative **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação**.
4. Selecione esta pasta `extension/coleta-whatsapp`.

## Instalação temporária no Firefox

1. Abra `about:debugging#/runtime/this-firefox`.
2. Clique em **Carregar extensão temporária**.
3. Selecione o arquivo `manifest.json` desta pasta.

Para instalação permanente no Firefox, o pacote precisa ser assinado pela
Mozilla. Para distribuição pública no Chrome, publique o pacote na Chrome Web
Store ou use a política corporativa administrada da organização.

## Uso

1. Abra **Configuração**, informe a URL do sistema e o token interno.
2. Cadastre os contatos com DDD. Números brasileiros recebem o código `55`
   automaticamente.
3. Informe o número da coleta e clique em **Consultar**.
4. Revise ou edite a mensagem.
5. Selecione o contato e clique em **Abrir no WhatsApp**.
6. Anexe manualmente o PDF da ordem de coleta, confira a conversa e confirme o
   envio.

O endpoint oficial da Brudam não documenta telefone, bairro, observação,
serviço e trecho na resposta de consulta. A extensão usa esses campos quando
eles vierem no retorno, mas não inventa valores quando estiverem ausentes.
